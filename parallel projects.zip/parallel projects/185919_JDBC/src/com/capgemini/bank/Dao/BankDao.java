package com.capgemini.bank.Dao;

import com.capgemini.bank.Beans.Customer;

public interface BankDao {

	Customer save(Customer c);

	String showBal(long accnum);

	void deposit(long acnum, double money1);

	void withdraw(long acnum1, double money);

	double transfer(long yaccnum, long raccnum, long amt);

}
