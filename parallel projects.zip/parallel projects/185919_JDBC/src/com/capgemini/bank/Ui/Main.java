package com.capgemini.bank.Ui;

import java.util.Scanner;

import com.capgemini.bank.Service.BankService;
import com.capgemini.bank.Service.BankServiceImpl;

public class Main {
	
	private static BankService service = new BankServiceImpl();
	private static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		
		System.out.println("Welcome to XYZ Bank!!!!\n");
		String ch = "yes";
		while(ch.equals("Yes") || ch.equals("yes"))
		{
			System.out.println("Please enter your choice\n\n1. Create Bank Account\n2. Show Balance\n3. Deposit\n4. Withdraw\n5. Fund Transfer\n");
			int choice = sc.nextInt();
			switch(choice)
			{
			
			case 1 : 
				service.saveCustomer();
				break;
			case 2 :
				System.out.println("Enter Account Number:");
				long accnum = sc.nextLong();
				System.out.println("The Account details are:\n"+service.showBalance(accnum));
				break;
			case 3 :
				System.out.println("Enter Account Number:");
				long acnum = sc.nextLong();
				System.out.println("Enter the amount to be deposited:");
				double money1 = sc.nextDouble();
				service.depositAmount(acnum, money1);
				break;
			case 4 :
				System.out.println("Enter Account Number:");
				long acnum1 = sc.nextLong();
				System.out.println("Enter Amount to withdraw:");
				double money = sc.nextDouble();
				service.withdrawAmount(acnum1, money);
				break;
			case 5 :
				System.out.println("Enter your Account Number:");
				long yaccnum = sc.nextLong();
				System.out.println("Enter recievers Account Number:");
				long raccnum = sc.nextLong();
				System.out.println("Enter ammount to be transfered:");
				long amt = sc.nextLong();
				System.out.println(service.fundTransfer(yaccnum, raccnum, amt));
				break;
			default :
				System.out.println("Please enter valid choice");
				break;
	
			}
			System.out.println("Do you want to continue: Yes or No");
			ch=sc.next();
		}
	}

}
